//A hello world file
//I wanted a file download/fetch, and here it is
#include <stdio.h>

int main()
{
  printf("Hello Ebuild World\n");
  return 0;
}
